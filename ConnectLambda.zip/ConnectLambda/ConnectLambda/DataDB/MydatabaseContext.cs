﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ConnectLambda.DataDB;

public partial class MydatabaseContext : DbContext
{
    public MydatabaseContext()
    {
    }

    public MydatabaseContext(DbContextOptions<MydatabaseContext> options)
        : base(options)
    {
    }

    //public virtual DbSet<Dept> Depts { get; set; }

    //public virtual DbSet<Emp> Emps { get; set; }

    public virtual DbSet<Student> Students { get; set; }

    //public virtual DbSet<StudentDatum> StudentData { get; set; }

    public virtual DbSet<Studept> Studepts { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=HSHLT-1694\\SQLEXPRESS01;Database=mydatabase;Trusted_Connection=True;trustservercertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Dept>(entity =>
        {
            entity.HasKey(e => e.Deptno).HasName("pk_dept");

            entity.ToTable("dept");

            entity.Property(e => e.Deptno)
                .HasColumnType("numeric(2, 0)")
                .HasColumnName("deptno");
            entity.Property(e => e.Dname)
                .HasMaxLength(14)
                .IsUnicode(false)
                .HasColumnName("dname");
            entity.Property(e => e.Loc)
                .HasMaxLength(13)
                .IsUnicode(false)
                .HasColumnName("loc");
        });

        modelBuilder.Entity<Emp>(entity =>
        {
            entity.HasKey(e => e.Empno).HasName("pk_emp");

            entity.ToTable("emp");

            entity.Property(e => e.Empno)
                .HasColumnType("numeric(4, 0)")
                .HasColumnName("empno");
            entity.Property(e => e.Comm)
                .HasColumnType("numeric(7, 2)")
                .HasColumnName("comm");
            entity.Property(e => e.Deptno)
                .HasColumnType("numeric(2, 0)")
                .HasColumnName("deptno");
            entity.Property(e => e.Ename)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasColumnName("ename");
            entity.Property(e => e.Hiredate)
                .HasColumnType("date")
                .HasColumnName("hiredate");
            entity.Property(e => e.Job)
                .HasMaxLength(9)
                .IsUnicode(false)
                .HasColumnName("job");
            entity.Property(e => e.Mgr)
                .HasColumnType("numeric(4, 0)")
                .HasColumnName("mgr");
            entity.Property(e => e.Sal)
                .HasColumnType("numeric(7, 2)")
                .HasColumnName("sal");

            entity.HasOne(d => d.DeptnoNavigation).WithMany(p => p.Emps)
                .HasForeignKey(d => d.Deptno)
                .HasConstraintName("fk_deptno");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.ToTable("student");

            entity.Property(e => e.Id)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("id");
            entity.Property(e => e.Class).HasColumnName("class");
            entity.Property(e => e.DeptId).HasColumnName("deptId");
            entity.Property(e => e.ExamDate)
                .HasColumnType("date")
                .HasColumnName("exam_date");
            entity.Property(e => e.Marks1)
                .HasColumnType("numeric(3, 0)")
                .HasColumnName("marks1");
            entity.Property(e => e.Marks2)
                .HasColumnType("numeric(3, 0)")
                .HasColumnName("marks2");
            entity.Property(e => e.Sname)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("sname");
        });

        modelBuilder.Entity<StudentDatum>(entity =>
        {
            entity.HasKey(e => e.StudentId);

            entity.ToTable("studentData");

            entity.Property(e => e.StudentId)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("studentId");
            entity.Property(e => e.Age).HasColumnName("age");
            entity.Property(e => e.ContactNo)
                .HasColumnType("numeric(10, 0)")
                .HasColumnName("contactNo");
            entity.Property(e => e.Gender)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("gender");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Standard).HasColumnName("standard");
        });

        modelBuilder.Entity<Studept>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_stud_dept");

            entity.ToTable("studept");

            entity.Property(e => e.Id)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("id");
            entity.Property(e => e.Deptid).HasColumnName("deptid");
            entity.Property(e => e.Dname)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("dname");
            entity.Property(e => e.Incharge)
                .HasMaxLength(20)
                .IsUnicode(false)
                .HasColumnName("incharge");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
