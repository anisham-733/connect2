﻿using System;
using System.Collections.Generic;

namespace ConnectLambda.DataDB;

public partial class Student
{
    public string Id { get; set; } = null!;

    public string Sname { get; set; } = null!;

    public int Class { get; set; }

    public DateTime ExamDate { get; set; }

    public decimal Marks1 { get; set; }

    public decimal Marks2 { get; set; }

    public int DeptId { get; set; }
}
