﻿using System;
using System.Collections.Generic;

namespace ConnectLambda.DataDB;

public partial class StudentDatum
{
    public string StudentId { get; set; } = null!;

    public string Name { get; set; } = null!;

    public int Age { get; set; }

    public int Standard { get; set; }

    public string Gender { get; set; } = null!;

    public decimal ContactNo { get; set; }
}
