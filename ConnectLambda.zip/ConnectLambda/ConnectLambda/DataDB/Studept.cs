﻿using System;
using System.Collections.Generic;

namespace ConnectLambda.DataDB;

public partial class Studept
{
    public string Id { get; set; } = null!;

    public int Deptid { get; set; }

    public string Dname { get; set; } = null!;

    public string Incharge { get; set; } = null!;
}
