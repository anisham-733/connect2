﻿using System;
using ConnectLambda.DataDB;

namespace ConnectLambda
{
    internal class Program
    {
        public static IQueryable<Student> stuList = null;
        public static IQueryable<Studept> deptList = null;
        public static void Main(string[] args)
        {
            MydatabaseContext dbContext = new MydatabaseContext();
            stuList = dbContext.Students.AsQueryable();
            deptList = dbContext.Studepts.AsQueryable();
            query1();
            //query2();
            //query3();
          //query4();
           // query6();
          //  query7();
        }
        public static void query1()
        {
            //Count the students that belong to dept iD 1
            var q1 = stuList.Where(x => x.DeptId == 1).Count();
            Console.WriteLine(q1);

            //print name of students that do not belong to dept 1 
            var q2 = stuList.Where(x => x.DeptId!=1);
            foreach (var item in q2)
            {
                Console.WriteLine($"{item.Sname} {item.DeptId} ");
            }

        }
        public static void query2()
        {
            int month = DateTime.Now.Month;
            DateTime d = DateTime.Now;
            //fetch names of all students whose exam date was 60 days ago
            var result = stuList.Where(s => s.ExamDate < DateTime.Now.AddDays(-60)).Select(s => s);
            Console.WriteLine("Today's date (MM/DD/YYYY) : "+d);
            foreach(var item in result)
            {
                Console.WriteLine($"Student Name : {item.Sname}, Examdate(M/dd/yyyy) : {item.ExamDate}");
            }
        }
        public static void query3()
        {
            //Joining on the basis of deptid and printing sname,id and deptname
            var result = stuList.Join(deptList, s => s.DeptId,
                d => d.Deptid, (s, d) => new
                {
                    StudentName = s.Sname,
                    DeptId = s.DeptId,
                    Dname = d.Dname,


                }).Select(s => s);

            foreach (var item in result)
            {
                Console.WriteLine($"{item.StudentName} {item.DeptId}{item.Dname}");
            }
        }

        public static void query4()
        {
            //Count the students present in different depts
            var result = stuList.GroupBy(s => s.DeptId);
            //foreach (var item in result)
            //{
            //    Console.WriteLine($"Key - (deptid) {item.Key} Count-> {item.Count()}");
            //}

            //count students and print deptid using grpjoin
            var result1 = stuList.GroupJoin(deptList,
                s => s.DeptId, d => d.Deptid,
                (ss, dd) => new
                {
                    DeptId = ss.DeptId,
                    Count = dd.Count(),
                    //Count = dd.Sum(d=>d.Incharge.Length)

                });
            foreach (var item in result1)
            {
                Console.WriteLine($"{ item.DeptId} { item.Count } ");
            }
            //result collection has same number of entries as first collection
            //grpjoin is similar to left outer join\
            //it produces all entries from the first list, each with a group of entries from the second list

        }
        public static void query5()
        { //dname and count of students
            var result = stuList.Join(deptList, s => s.DeptId, d => d.Deptid,
                (s, d) =>
            new
            {
                Stu = s,
                Dept = d.Dname,
                GroupField = d.Dname

            }).GroupBy(s => s.GroupField);
            foreach (var item in result)
            {
                Console.WriteLine($"{item.Key} {item.Count()}");
            }
        }
        public static void query6()
        {
            //count only the students for deptname mathematics. and total numbe rof students in maths ans science dept
            var result = stuList.Join(deptList, s => s.DeptId, d => d.Deptid,
                (stu, dept) => new
                {
                    stu,
                    dept
                }).GroupBy(i => new
                {

                    i.dept.Dname
                }).Where(i=>i.Key.Dname.StartsWith("M")|| i.Key.Dname.StartsWith("S")).Select(i=>new
                {
                    dname = i.Key.Dname,
                    count = i.Count(),
        
                });
            int sum = 0;
            foreach(var q in result)
            {
                sum += q.count;
                Console.WriteLine($"{q.dname} {q.count}");
            }
            Console.WriteLine(sum);
        }
        public static void query7()
        {
            //students who study in class 8 and order their incharge name
            var result = stuList.Join(deptList, s => s.DeptId, d => d.Deptid,
                (s, d) => new
                {
                    StudentName = s.Sname,
                    Class = s.Class,
                    InchargeName = d.Incharge
                }).Where(s => s.Class == 8).OrderBy(s => new
                {
                    s.InchargeName,
                    s.StudentName
                }).Select(s => s);
            foreach(var item in result)
            {
                Console.WriteLine($"{item.StudentName} {item.Class} {item.InchargeName}");
            }
        }
        public static void query8()
        {
            //group all those students whose
        }










    }
}
    