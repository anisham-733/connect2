﻿using System;
using System.Collections.Generic;

namespace conn2.TestDB;

public partial class Dept
{
    public decimal Deptno { get; set; }

    public string? Dname { get; set; }

    public string? Loc { get; set; }

    public virtual ICollection<Emp> Emps { get; } = new List<Emp>();
}
