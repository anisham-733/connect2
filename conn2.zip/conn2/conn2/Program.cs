﻿using conn2.TestDB;

using System;
using System.Threading.Tasks.Dataflow;

namespace conn2;

internal class Program
{
    public static IQueryable<Emp> empList = null;
    public static IQueryable<Dept> deptList = null;

    public static void Main(String[] args)
    {

        MydatabaseContext _dbContext = new MydatabaseContext();
        empList = _dbContext.Emps.AsQueryable();

        deptList = _dbContext.Depts.AsQueryable();
        //Query1 - Get the count of employees present in different departments.
        var query1 = from emp in empList
                     join dept in deptList on emp.Deptno equals dept.Deptno
                     group emp by emp.Deptno;

        
        //  select new
        //{
        //    EmpName = emp.Ename,
        //    DeptNo = emp.Deptno,
        //};

        foreach (var record in query1)
        {
            Console.WriteLine($"Key : {record.Key}, Values : {record.Count()} ");
        }
        //callfunc1();
        //callfunc2();
        //callfunc3();
        //callfunc4();
        //callfunc5();


    }
    public static void callFunc2()
    {
        //Query2 - Give the list of Manager(s) whose name starts with 'J'

        var query2 = (from emp in empList
                      join dept in deptList
                      on emp.Deptno equals dept.Deptno
                      where emp.Ename.Contains("A")
                      select new
                      {
                          EmpName = emp.Ename,
                          DeptName = dept.Dname,
                          JobName = emp.Job
                      }).ToList();


        foreach (var record1 in query2)
        {
            Console.WriteLine($"{record1.EmpName} {record1.DeptName} {record1.JobName}");
        }
    }

    //public static void callFunc3()
    //{
    //    //Query3
    //    //left join-all records of left collection irrespective of match and matching records of right collection
    //    //-DefaultIfEmpty() - on the sequence if matching elements from group join
    //    var query3 = from emp in empList
    //                 join dept in deptList on emp.Deptno equals dept.Deptno into groupJoin

    //                 from groupResult in groupJoin.DefaultIfEmpty()
    //                 select new
    //                 {
    //                     Emp = emp,
    //                     Dept = groupResult,
    //                     groupResult.Deptno,
    //                     groupResult.Dname
    //                 };
    //    foreach (var record in query3)
    //    {
    //        //Console.WriteLine("\n" + record.Count());
    //        //Console.WriteLine($"{record.Emp.Ename} {record.Dname} {record.Deptno} {record.Emp.Job}");
    //    }

    //}

    //public static void callFunc4()
    //{

    //    //right outer join-swap the two tables
    //    var query4 = from dept in deptList
    //                 join emp in empList on dept.Deptno equals emp.Deptno into groupJoin
    //                 from groupRes in groupJoin.DefaultIfEmpty()
    //                 select new
    //                 {
    //                     groupRes,
    //                     Dept = dept
    //                 };
    //    foreach (var record in query4)
    //    {
    //        //Console.WriteLine($"{record.Dept.Deptno}  {record.Dept.Dname}");
    //    }


    //}

    //public static void callFunc5()
    //{
    //    //query5
    //    var query5 = from emp in empList group emp by emp.Job;
    //    foreach (var record in query5)
    //    {
    //        Console.WriteLine($"Key : {record.Key}");
    //        foreach (var values in record)
    //        {
    //            Console.WriteLine($"{values.Ename}");
    //        }
    //    }

    //}

    public static void callFunc1()
    {

        


    }
        
       
    
}